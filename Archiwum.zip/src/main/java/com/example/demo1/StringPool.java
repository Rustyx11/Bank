package com.example.demo1;

public class StringPool {
    public static final String BLANK = "";

    private StringPool() {

    }
}